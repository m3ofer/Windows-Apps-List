# Windows 11 Setup
---
```
rgb(249, 191, 82)
#f9bf52
```

##